const Listing = require("../models/listing.js");

// Show all listings
module.exports.index = async (req, res, next) => {
  try {
    const allListings = await Listing.find({});
    return res.render("listings/index.ejs", { allListings });
  } catch (err) {
    next(err);
  }
};

// Show listings filtered by category
module.exports.filterByCategory = async (req, res, next) => {
  try {
    const { category } = req.params;
    const listings = await Listing.find({ category });

    if (!listings || listings.length === 0) {
      req.flash("error", "No listings exist for this category");
      return res.redirect("/listings");
    }

    return res.render("listings/index.ejs", { allListings: listings });
  } catch (err) {
    next(err);
  }
};

// Render new listing form
module.exports.renderNewForm = (req, res) => {
  return res.render("listings/new.ejs");
};

// Show single listing
module.exports.showListing = async (req, res, next) => {
  try {
    const { id } = req.params;
    const listing = await Listing.findById(id)
      .populate({ path: "reviews", populate: { path: "author" } })
      .populate("owner");

    if (!listing) {
      req.flash("error", "The listing you requested does not exist!");
      return res.redirect("/listings");
    }

    return res.render("listings/show.ejs", { listing });
  } catch (err) {
    next(err);
  }
};

// Create new listing
module.exports.createListing = async (req, res, next) => {
  try {
    const { path: url, filename } = req.file;
    const newListing = new Listing(req.body.listing);

    newListing.owner = req.user._id;
    newListing.image = { filename, url };

    await newListing.save();
    req.flash("success", "New listing created");
    return res.redirect("/listings");
  } catch (err) {
    next(err);
  }
};

// Render edit listing form
module.exports.renderEditForm = async (req, res, next) => {
  try {
    const { id } = req.params;
    const listing = await Listing.findById(id);

    if (!listing) {
      req.flash("error", "The listing you requested does not exist!");
      return res.redirect("/listings");
    }

    req.flash("success", "Listing ready to edit");
    return res.render("listings/edit.ejs", { listing });
  } catch (err) {
    next(err);
  }
};

// Update listing
module.exports.updateListing = async (req, res, next) => {
  try {
    const { id } = req.params;
    const listing = await Listing.findByIdAndUpdate(
      id,
      { ...req.body.listing },
      { new: true }
    );

    if (!listing) {
      req.flash("error", "The listing you are trying to update does not exist!");
      return res.redirect("/listings");
    }

    if (req.file) {
      const { path: url, filename } = req.file;
      listing.image = { url, filename };
      await listing.save();
    }

    req.flash("success", "Listing updated!");
    return res.redirect(`/listings/${id}`);
  } catch (err) {
    next(err);
  }
};

// Delete listing
module.exports.deleteListing = async (req, res, next) => {
  try {
    const { id } = req.params;
    const deletedListing = await Listing.findByIdAndDelete(id);

    if (!deletedListing) {
      req.flash("error", "The listing you are trying to delete does not exist!");
      return res.redirect("/listings");
    }

    req.flash("success", "Listing deleted");
    return res.redirect("/listings");
  } catch (err) {
    next(err);
  }
};

// Privacy page
module.exports.Privacy = (req, res) => {
  return res.render("listings/privacy.ejs");
};

// Terms & Conditions page
module.exports.TermsConditions = (req, res) => {
  return res.render("listings/terms.ejs");
};
